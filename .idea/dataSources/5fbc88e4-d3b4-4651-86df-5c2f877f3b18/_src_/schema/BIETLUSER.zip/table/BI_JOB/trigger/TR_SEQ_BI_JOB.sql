CREATE TRIGGER TR_SEQ_BI_JOB
BEFORE INSERT
  ON BI_JOB
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.JOB_ID IS NULL or :new.JOB_ID=0 THEN
    select SEQ_BI_JOB.nextval
    into nextid
    from sys.dual;
    :new.JOB_ID:=nextid;
  end if;
end TR_SEQ_BI_JOB;
/
