CREATE TRIGGER TR_SEQ_BI_INIT_EXPORT
BEFORE INSERT
  ON BI_INIT_EXPORT
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.TABLE_ID IS NULL or :new.TABLE_ID=0 THEN
    select SEQ_BI_INIT_EXPORT.nextval
    into nextid
    from sys.dual;
    :new.TABLE_ID:=nextid;
  end if;
end TR_SEQ_BI_INIT_EXPORT;
/
