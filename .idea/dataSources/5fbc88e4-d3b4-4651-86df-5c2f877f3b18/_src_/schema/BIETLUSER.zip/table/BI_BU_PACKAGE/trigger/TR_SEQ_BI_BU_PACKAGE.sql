CREATE TRIGGER TR_SEQ_BI_BU_PACKAGE
BEFORE INSERT
  ON BI_BU_PACKAGE
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.PACKAGE_ID IS NULL or :new.PACKAGE_ID=0 THEN
    select SEQ_BI_BU_PACKAGE.nextval
    into nextid
    from sys.dual;
    :new.PACKAGE_ID:=nextid;
  end if;
end TR_SEQ_BI_BU_PACKAGE;
/
