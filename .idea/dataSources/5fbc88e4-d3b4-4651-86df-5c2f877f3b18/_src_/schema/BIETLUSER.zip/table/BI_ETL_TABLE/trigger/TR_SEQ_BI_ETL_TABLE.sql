CREATE TRIGGER TR_SEQ_BI_ETL_TABLE
BEFORE INSERT
  ON BI_ETL_TABLE
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.TABLE_ID IS NULL or :new.TABLE_ID=0 THEN
    select SEQ_BI_ETL_TABLE.nextval
    into nextid
    from sys.dual;
    :new.TABLE_ID:=nextid;
  end if;
end TR_SEQ_BI_ETL_TABLE;
/
