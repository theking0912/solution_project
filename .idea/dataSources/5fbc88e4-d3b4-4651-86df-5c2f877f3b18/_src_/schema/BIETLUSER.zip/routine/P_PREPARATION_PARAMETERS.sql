CREATE procedure p_preparation_parameters(pa_order_date varchar2) is
begin
  --核查生成的数据准确性
  /*  select order_date, count(1)
    from tbl_trans_things_num
   group by order_date
   order by order_date asc;
  
  select order_date, count(10)
    from box_sum_result
   group by order_date
   order by order_date asc;*/

  -----------------------------------------------------------------三点
  --create table tbl_box_line_result as 
  insert into tbl_box_line_result
    select a.station_begin,
           a.station_mid,
           a.station_end,
           part1.part1_num + part2.part2_num as line1_length,
           part2.part2_num + part3.part3_num as line2_length,
           part3.part3_num + part1.part1_num as line3_length,
           begin_1.line_begin,
           begin_2.line_mid,
           begin_3.line_end,
           part1.part1_num + part2.part2_num + part2.part2_num +
           part3.part3_num + part3.part3_num + part1.part1_num as length_sum,
           thing_1.box_begin,
           thing_2.box_mid box_mid,
           thing_3.box_end,
           a.sum_box_num,
           'C' as point_type,
           thing_1.per_box_begin,
           thing_2.per_box_mid,
           thing_3.per_box_end,
           a.sum_per_box_num,
           thing_1.order_date
      from box_sum_result a
     outer apply (select point_2_point_num as line_begin
                    from tbl_trans_info_detail
                   where type = 1
                     and station_begin = a.station_begin) begin_1
     outer apply (select point_2_point_num as line_mid
                    from tbl_trans_info_detail
                   where type = 1
                     and station_begin = a.station_mid) begin_2
     outer apply (select point_2_point_num as line_end
                    from tbl_trans_info_detail
                   where type = 1
                     and station_begin = a.station_end) begin_3
     outer apply (select nvl(point_2_point_num, 0) as part1_num
                    from tbl_trans_info_detail b
                   where (a.station_begin = b.station_begin and
                         a.station_mid = b.station_end)
                      or (a.station_mid = b.station_begin and
                         a.station_begin = b.station_end)
                     and b.type = 0) part1
     outer apply (select nvl(point_2_point_num, 0) as part2_num
                    from tbl_trans_info_detail b
                   where (a.station_mid = b.station_begin and
                         a.station_end = b.station_end)
                      or (a.station_end = b.station_begin and
                         a.station_mid = b.station_end)
                     and b.type = 0) part2
     outer apply (select nvl(point_2_point_num, 0) as part3_num
                    from tbl_trans_info_detail b
                   where (a.station_end = b.station_begin and
                         a.station_begin = b.station_end)
                      or (a.station_begin = b.station_begin and
                         a.station_end = b.station_end)
                     and b.type = 0) part3
     outer apply (select box_num     as box_begin,
                         per_box_num as per_box_begin,
                         order_date
                    from tbl_trans_things_num
                   where station_name = a.station_begin
                     and order_date = a.order_date) thing_1
     outer apply (select box_num as box_mid, per_box_num as per_box_mid
                    from tbl_trans_things_num
                   where station_name = a.station_mid
                     and order_date = a.order_date) thing_2
     outer apply (select box_num as box_end, per_box_num as per_box_end
                    from tbl_trans_things_num
                   where station_name = a.station_end
                     and order_date = a.order_date) thing_3
     where a.station_mid is not null
       and substr(to_char(a.order_date, 'yyyyMMdd'), 1, 8) = pa_order_date;

  -----------------------------------------------------------------两点
  insert into tbl_box_line_result
    select a.station_begin,
           '-' as station_mid,
           a.station_end,
           part1.line1_length,
           0 as line2_length,
           0 as line3_length,
           begin_1.line_begin,
           0 as line_mid,
           begin_2.line_end,
           part1.length_sum,
           thing_1.box_begin,
           0 as box_mid,
           thing_3.box_end,
           a.sum_box_num,
           'B' as point_type,
           thing_1.per_box_begin,
           0 as per_box_mid,
           thing_3.per_box_end,
           a.sum_per_box_num,
           thing_1.order_date
      from box_sum_result a
     outer apply (select point_2_point_num as line_begin
                    from tbl_trans_info_detail
                   where type = 1
                     and station_begin = a.station_begin) begin_1
     outer apply (select point_2_point_num as line_end
                    from tbl_trans_info_detail
                   where type = 1
                     and station_begin = a.station_end) begin_2
     outer apply (select nvl(point_2_point_num, 0) as line1_length,
                         nvl(point_2_point_num, 0) as length_sum
                    from tbl_trans_info_detail b
                   where (a.station_begin = b.station_begin and
                         a.station_end = b.station_end)
                      or (a.station_end = b.station_begin and
                         a.station_begin = b.station_end)
                     and b.type = 0) part1
     outer apply (select box_num     as box_begin,
                         per_box_num as per_box_begin,
                         order_date
                    from tbl_trans_things_num
                   where station_name = a.station_begin
                     and order_date = a.order_date) thing_1
     outer apply (select box_num as box_end, per_box_num as per_box_end
                    from tbl_trans_things_num
                   where station_name = a.station_end
                     and order_date = a.order_date) thing_3
     where a.station_mid is null
       and substr(to_char(a.order_date, 'yyyyMMdd'), 1, 8) = pa_order_date;
  -----------------------------------------------------------------直达
  insert into tbl_box_line_result
    select a.station_name as station_begin,
           '-' as station_mid,
           '-' as station_end,
           0 as line1_length,
           0 as line2_length,
           0 as line3_length,
           begin_1.line_begin,
           0 as line_mid,
           0 as line_end,
           0 as length_sum,
           a.box_num as box_begin,
           0 as box_mid,
           0 as box_end,
           a.box_num as sum_box_num,
           'A' as point_type,
           a.per_box_num as per_box_begin,
           0 as per_box_mid,
           0 as per_box_end,
           a.box_num as sum_per_box_num,
           order_date
      from tbl_trans_things_num a
     outer apply (select point_2_point_num as line_begin
                    from tbl_trans_info_detail
                   where type = 1
                     and station_begin = a.station_name) begin_1
     where substr(to_char(order_date, 'yyyyMMdd'), 1, 8) = pa_order_date;
  -----------------------------------------------------------------删除不适合的组合
  --select * from tbl_box_line_result where point_type <> 'C' and (station_begin in ('西三旗','上地','育新') and station_end in ('西三旗','上地','育新'));
  delete from tbl_box_line_result where point_type <> 'C' and (station_begin in ('西三旗','上地','育新') and station_end in ('西三旗','上地','育新'));
  -----------------------------------------------------------------

end p_preparation_parameters;
/
