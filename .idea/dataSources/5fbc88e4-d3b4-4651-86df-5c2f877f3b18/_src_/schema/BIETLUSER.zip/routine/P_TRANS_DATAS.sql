CREATE procedure P_TRANS_DATAS is
begin
       ---------------------------------------------------------销售切片程序
  --删除切片表数据
  delete from tb_kpi_info;
  /*delete from tb_report_bi_thbi;*/
  delete from tb_report_bi_report;
  delete from tb_report_bi_service_side_desc;
  delete FROM TB_REPORT_BI where substr(to_char(QINGQIUJH_DATE,'yyyyMMdd'),1,6) = substr(to_char(sysdate,'yyyyMMdd'),1,6);


  --数据进入正式表
  insert into BIetluser.TB_REPORT_BI(
           MONTH,
           WEEK,
           PART,
           PINGZHENG_DATE,
           QINGQIUJH_DATE,
           HEAD_CUSTOMER_CODE,
           MANAGEMENT_TYPE,
           CUSTOMER_TYPE,
           ACHIEVEMEN_CONTRIBUTIO_FLAG_8,
           CUSTOMER_SHORT_NAME,
           SALE_SIDE,
           CUSTOMER_DESCRIPTION,
           SERVICE_SIDE,
           SERVICE_SIDE_DESC,
           PAYER,
           SALES_DOCUMENT,
           PROJECT_NO,
           LEVEL_A,
           LEVEL_B,
           ITEM_NUMBER,
           DESCRIPTION,
           SHIP_UOM,
           POSTING_QTY,
           ORDER_QTY,
           SALES_UOM_DESC,
           PAYER_DESCRIPTION,
           TAX_AMOUNT_ORDER,
           NET_VALUE,
           POSTING_AMOUNT,
           CONDITIONAL_PRICE,
           TAX,
           FACTORY,
           COST_POSTING,
           SALES_ORGANIZATION,
           DOCUMENT_CONDITION_NUMBER,
           CUSTOMER_LOCAL,
           SALE_LOCAL,
           SALES_DEPARTMENT,
           SALES_TEAM,
           TAX_RATE,
           GROSS_PROFIT)
    select MONTH,
           WEEK,
           PART,
           PINGZHENG_DATE,
           QINGQIUJH_DATE,
           HEAD_CUSTOMER_CODE,
           MANAGEMENT_TYPE,
           CUSTOMER_TYPE,
           ACHIEVEMEN_CONTRIBUTIO_FLAG_8,
           CUSTOMER_SHORT_NAME,
           SALE_SIDE,
           CUSTOMER_DESCRIPTION,
           SERVICE_SIDE,
           SERVICE_SIDE_DESC,
           PAYER,
           SALES_DOCUMENT,
           PROJECT_NO,
           LEVEL_A,
           LEVEL_B,
           ITEM_NUMBER,
           DESCRIPTION,
           SHIP_UOM,
           POSTING_QTY,
           ORDER_QTY,
           SALES_UOM_DESC,
           PAYER_DESCRIPTION,
           TAX_AMOUNT_ORDER,
           NET_VALUE,
           POSTING_AMOUNT,
           CONDITIONAL_PRICE,
           TAX,
           FACTORY,
           COST_POSTING,
           SALES_ORGANIZATION,
           DOCUMENT_CONDITION_NUMBER,
           CUSTOMER_LOCAL,
           SALE_LOCAL,
           SALES_DEPARTMENT,
           SALES_TEAM,
           TAX_RATE,
           GROSS_PROFIT
      from BIetluser.TB_REPORT_BI_TEMP
     where substr(to_char(QINGQIUJH_DATE, 'yyyyMMdd'), 1, 6) = 
           substr(to_char(sysdate, 'yyyyMMdd'), 1, 6);
           
  delete from tb_report_bi_temp;
  
  --合并销售人员数据
  update TB_REPORT_BI a
     set (sale_group_leader,saler)=(select b.sale_group_leader,b.saler
    from tb_kpi_data_conf_details b
   where b.customer_code=a.head_customer_code
     and substr(to_char(b.kpi_date, 'yyyyMMdd'), 1, 6) = 
         substr(to_char(a.qingqiujh_date, 'yyyyMMdd'), 1, 6))
   where exists (select 1
    from tb_kpi_data_conf_details b
   where b.customer_code=a.head_customer_code);

-----------------------------
 	--更新上月次到老
 	--更新上月新到次
  --select customer_type from tb_report_bi_temp where trunc(qingqiujh_date, 'MM') = trunc(add_months(sysdate, -4), 'MM') and customer_type = '次新客户';
  --select customer_type from tb_report_bi_temp where trunc(qingqiujh_date, 'MM') = trunc(add_months(sysdate, -4), 'MM') and customer_type = '新客户';
-----------------------------

  --生成环同比数据
  /*insert into BIetluser.TB_REPORT_BI_THBI
    with huanbi as
     (select data_14.CUSTOMER_TYPE,
             data_7.amount_sum_7 as seven_days_local,
             data_14.amount_sum_14 - data_7.amount_sum_7 as seven_days_after,
             round(((data_7.amount_sum_7) /
                   (data_14.amount_sum_14 - data_7.amount_sum_7)) - 1,
                   2) as huanbi
        from (select *
                from (select qingqiujh_date as max_date,
                             qingqiujh_date - 14 as date_14,
                             qingqiujh_date - 7 as date_7
                        from BIetluser.TB_REPORT_BI
                       order by QINGQIUJH_DATE desc)
               where rownum <= 1) date_details
       outer apply (select CUSTOMER_TYPE, sum(TAX_AMOUNT_ORDER) amount_sum_14
                     from BIetluser.TB_REPORT_BI
                    where qingqiujh_date <= date_details.max_date
                      and qingqiujh_date > date_details.date_14
                    group by CUSTOMER_TYPE) data_14
       outer apply (select CUSTOMER_TYPE, sum(TAX_AMOUNT_ORDER) amount_sum_7
                     from BIetluser.TB_REPORT_BI
                    where qingqiujh_date <= date_details.max_date
                      and qingqiujh_date > date_details.date_7
                      and CUSTOMER_TYPE = data_14.CUSTOMER_TYPE
                    group by CUSTOMER_TYPE) data_7)
    select tong.CUSTOMER_TYPE,
           tong.amount_sum_local,
           tong.amount_sum_before,
           tong.tongbi,
           huan.seven_days_local,
           huan.seven_days_after,
           huan.huanbi
      from (select data_local.CUSTOMER_TYPE,
                   data_local.amount_sum_local as amount_sum_local,
                   data_before.amount_sum_before as amount_sum_before,
                   round((data_local.amount_sum_local /
                         data_before.amount_sum_before) - 1,
                         2) as tongbi
              from (select *
                      from (select qingqiujh_date date_max_local,
                                   ADD_MONTHS(qingqiujh_date, -1) date_max_before,
                                   trunc(qingqiujh_date, 'mm') date_begin_local,
                                   ADD_MONTHS((trunc(qingqiujh_date, 'mm')),
                                              -1) date_begin_before
                              from BIetluser.TB_REPORT_BI
                             order by qingqiujh_date desc)
                     where rownum <= 1) date_details
             outer apply (select CUSTOMER_TYPE,
                                sum(TAX_AMOUNT_ORDER) amount_sum_local
                           from BIetluser.TB_REPORT_BI
                          where qingqiujh_date <=
                                date_details.date_max_local
                            and qingqiujh_date >=
                                date_details.date_begin_local
                          group by CUSTOMER_TYPE) data_local
             outer apply (select CUSTOMER_TYPE,
                                sum(TAX_AMOUNT_ORDER) amount_sum_before
                           from BIetluser.TB_REPORT_BI
                          where qingqiujh_date <=
                                date_details.date_max_before
                            and qingqiujh_date >=
                                date_details.date_begin_before
                            and CUSTOMER_TYPE = data_local.CUSTOMER_TYPE
                          group by CUSTOMER_TYPE) data_before) tong
     inner join huanbi huan
        on tong.CUSTOMER_TYPE = huan.CUSTOMER_TYPE;*/

  --生成达成率数据(未添加标准值)
  --truncate table tb_kpi_info;
  insert into tb_kpi_info(
         part
         ,qingqiujh_date
         ,sale_group_leader
         ,saler
         ,head_customer_code
         ,customer_short_name
         ,tax_amount_order
         ,kpi_amount_w
         ,customer_count
         ,avg_kpi_amount_w)
  select trbt.part
         ,trbt.qingqiujh_date
         ,trbt.sale_group_leader
         ,trbt.saler
         ,trbt.head_customer_code
         ,trbt.customer_short_name
         ,sum(trbt.TAX_AMOUNT_ORDER) tax_amount_order
         ,0 kpi_amount_w
         ,0 customer_count
         ,0 avg_kpi_amount_w
    from BIetluser.tb_report_bi trbt
   where substr(to_char(trbt.QINGQIUJH_DATE, 'yyyyMMdd'), 1, 6) >= 
         substr(to_char(add_months(sysdate,-3), 'yyyyMMdd'), 1, 6)
   group by trbt.part, trbt.qingqiujh_date,trbt.sale_group_leader,trbt.saler,trbt.head_customer_code,trbt.customer_short_name
   order by trbt.qingqiujh_date desc;

  --生成达成率数据(添加标准值)
  update tb_kpi_info tki 
     set (tki.kpi_amount_w) = (select kpi.kpi_amount_w * 10000 as kpi_amount_w
                 from tb_kpi_data_conf_details kpi
                where kpi.part = tki.part
                  and kpi.customer_code = tki.head_customer_code
                  and substr(to_char(kpi.kpi_date, 'yyyyMMdd'), 1, 6) = substr(to_char(tki.qingqiujh_date, 'yyyyMMdd'), 1, 6)) 
  where exists (select 1
                 from tb_kpi_data_conf_details kpi
                where kpi.part = tki.part
                  and kpi.customer_code = tki.head_customer_code
                  and substr(to_char(kpi.kpi_date, 'yyyyMMdd'), 1, 6) = substr(to_char(tki.qingqiujh_date, 'yyyyMMdd'), 1, 6));

  --更新，客户数量
  update tb_kpi_info tki 
     set (tki.customer_count) = (select count(head_customer_code) customer_count
                                 from tb_kpi_info info
                                where info.part = tki.part
                                  and info.head_customer_code = tki.head_customer_code
                                  and substr(to_char(info.qingqiujh_date, 'yyyyMMdd'), 1, 6) = substr(to_char(tki.qingqiujh_date, 'yyyyMMdd'), 1, 6)
                                 group by part,substr(to_char(info.QINGQIUJH_DATE, 'yyyyMMdd'), 1, 6),info.head_customer_code) 
  where exists (select 1
                  from tb_kpi_info info
                 where info.part = tki.part
                   and info.head_customer_code = tki.head_customer_code
                   and substr(to_char(info.qingqiujh_date, 'yyyyMMdd'), 1, 6) = substr(to_char(tki.qingqiujh_date, 'yyyyMMdd'), 1, 6)
                 group by part,substr(to_char(info.QINGQIUJH_DATE, 'yyyyMMdd'), 1, 6),info.head_customer_code);
  --更新平均值
  update tb_kpi_info 
     set AVG_KPI_AMOUNT_W = kpi_amount_w/substr(to_char(last_day(qingqiujh_date), 'yyyymmdd'),7,8);

  --生成树形图（商品）二级表
  insert into TB_REPORT_BI_REPORT
  select part
         ,month
         ,qingqiujh_date
         ,management_type
         ,customer_type
         ,head_customer_code
         ,customer_short_name
         ,sale_group_leader
         ,saler
         ,level_a
         ,level_b
         ,description
         ,sum(tax_amount_order) as tax_amount_order
         ,0 KPI_AMOUNT_W
         ,sum(net_value) as net_value
         ,sum(gross_profit) as gross_profit
         ,case when sum(net_value) = 0 and sum(gross_profit) < 0 then -1
               when sum(net_value) = 0 and sum(gross_profit) > 0 then 1
               when sum(net_value) = 0 and sum(gross_profit) = 0 then 0
               else sum(gross_profit)/sum(net_value) 
          end as gross_profit_margin
         ,0.075 as standard_rate
    from tb_report_bi
   where substr(to_char(qingqiujh_date, 'yyyyMMdd'), 1, 6) >= 
         substr(to_char(add_months(sysdate,-3), 'yyyyMMdd'), 1, 6)
    group by   
          part
         ,month
         ,qingqiujh_date
         ,management_type
         ,customer_type
         ,head_customer_code
         ,customer_short_name
         ,sale_group_leader
         ,saler
         ,level_a
         ,level_b
         ,description;
  
  --生成树形图（送达方）二级表
  insert into TB_REPORT_BI_SERVICE_SIDE_DESC
  select part
           ,month
           ,qingqiujh_date
           ,management_type
           ,customer_type
           ,head_customer_code
           ,customer_short_name
           ,service_side_desc
           ,sale_group_leader
           ,saler
           ,level_a
           ,level_b
           ,sum(tax_amount_order) as tax_amount_order
           ,0 KPI_AMOUNT_W
           ,sum(net_value) as net_value
           ,sum(gross_profit) as gross_profit
           ,case when sum(net_value) = 0 and sum(gross_profit) < 0 then -1
                 when sum(net_value) = 0 and sum(gross_profit) > 0 then 1
                 when sum(net_value) = 0 and sum(gross_profit) = 0 then 0
                 else sum(gross_profit)/sum(net_value) 
            end as gross_profit_margin
           ,0.075 as standard_rate
      from tb_report_bi
     where substr(to_char(qingqiujh_date, 'yyyyMMdd'), 1, 6) >= 
           substr(to_char(add_months(sysdate,-3), 'yyyyMMdd'), 1, 6)
      group by   
            part
           ,month
           ,qingqiujh_date
           ,management_type
           ,customer_type
           ,head_customer_code
           ,customer_short_name
           ,service_side_desc
           ,sale_group_leader
           ,saler
           ,level_a
           ,level_b;
  
  --填充kpi值
  update tb_report_bi_report tki 
     set (tki.kpi_amount_w) = (select kpi.kpi_amount_w * 10000/(trunc(add_months(kpi.kpi_date, 1), 'MM') - trunc(kpi.kpi_date, 'MM')) as kpi_amount_w
                 from tb_kpi_data_conf_details kpi
                where kpi.part = tki.part
                  and kpi.customer_code = tki.head_customer_code
                  and substr(to_char(kpi.kpi_date, 'yyyyMMdd'), 1, 6) = substr(to_char(tki.qingqiujh_date, 'yyyyMMdd'), 1, 6)) 
  where exists (select 1
                 from tb_kpi_data_conf_details kpi
                where kpi.part = tki.part
                  and kpi.customer_code = tki.head_customer_code
                  and substr(to_char(kpi.kpi_date, 'yyyyMMdd'), 1, 6) = substr(to_char(tki.qingqiujh_date, 'yyyyMMdd'), 1, 6));
                  
  --生成地图数据
  --demo1
  update TB_COUNTRIES_ISO tki
   set (tki.tax_amount_order) =
       (select sum(tax_amount_order) tax_amount_order
          from tb_report_bi
         where customer_local is not null
           and tki.NAME_OF_PROVINCE = customer_local
         group by customer_local)
 where exists (select 1
          from tb_report_bi
         where customer_local is not null
           and tki.NAME_OF_PROVINCE = customer_local
         group by customer_local);
  
  --demo2       
  update tb_map_report tki
   set (tki.ISO) =
       (select ISO from TB_COUNTRIES_ISO where name_of_province = customer_local)
 where exists (select 1 from TB_COUNTRIES_ISO where name_of_province = customer_local);         

 --------------------------------------------
/*  --上月同天
  select add_months(sysdate,-1) from dual;
  --上月第一天
  select to_char(add_months(trunc(sysdate, 'mm'),-1), 'yyyyMMdd') from dual;
  --本月第一天
  select to_char(trunc(sysdate, 'mm'), 'yyyyMMdd') from dual;
  --昨天
  select sysdate - 1 from dual;
  --今天
  select sysdate from dual;
*/


end P_TRANS_DATAS;
/
