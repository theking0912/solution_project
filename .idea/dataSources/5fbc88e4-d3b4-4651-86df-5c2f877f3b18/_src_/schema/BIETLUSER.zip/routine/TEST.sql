CREATE procedure test is
  ARKTX_return nvarchar2(100);
  v_count  integer  := 0;
begin
  select ARKTX
    into ARKTX_return
    from prd_bi_report.ta_sale_daily_price
   where rownum = 1;
   
   v_count := SQL%ROWCOUNT;
   dbms_output.put_line(v_count);
  
end test;
/
