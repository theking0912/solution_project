CREATE procedure P_DEL_TW_REPEAT_DATA is

  truncate_sql       varchar2(4000);
  insert_sql         varchar2(4000);
  insert_coluom_name varchar2(4000);
  delete_sql         varchar2(4000);
  ti_table           varchar2(100);
  tw_table           varchar2(100);
  user_shema         varchar2(100);
  where_str          varchar2(4000);
  table_name_para    varchar2(100);
begin
  --����TI_TABLE,TW_TABLE,user_shema.
  ti_table   := 'TI_SAP_';
  tw_table   := 'TW_SAP_';
  user_shema := 'PRD_BI_DATA.';
  --����һ�������滻����FULL  OR  PK
  for cur_s in (select c.table_id,
                       c.table_name,
                       c.ext_system,
                       c.run_lastdate,
                       c.run_status,
                       c.load_table_name,
                       c.LOAD_COVERNO_TYPE,
                       c.load_coverno_value
                  from BIetluser.bi_job a
                 inner join BIetluser.bi_job_step b
                    on a.job_id = b.job_id
                   and b.object_type = 'TABLE'
                 inner join BIetluser.bi_etl_table c
                    on b.object_id = c.table_id
                 where c.is_valid = 1
                   and a.job_name = 'IMPORT_ALL'
                 order by b.sort) loop
    --��===============================================================================================================��
    --��======================================��TYPEΪFULLʱ============================================================��
    --��===============================================================================================================��
    if cur_s.LOAD_COVERNO_TYPE = 'FULL' then
      --|==========================================================================================|
      --|=========================================FULL_TRUNCATE====================================|
      --|==========================================================================================|
      truncate_sql := 'truncate table ' || user_shema || tw_table ||
                      cur_s.table_name;
      dbms_output.put_line('truncate_sql_FULL :' || truncate_sql);
      ------------------FULLִ��--------------��truncate_sql�� 
      EXECUTE IMMEDIATE truncate_sql;
      dbms_output.put_line(truncate_sql);
      --|==========================================================================================|
      --|=========================================FULL_INSERT======================================|
      --|==========================================================================================|
      table_name_para := ti_table || cur_s.Table_Name;
      select sys.wm_concat(b.column_name)
        into insert_coluom_name
        from all_tables a, all_tab_columns b, all_objects c
       where a.table_name = b.table_name
         and a.owner = b.owner
         and a.owner = c.owner
         and a.table_name = c.object_name
         and a.table_name = table_name_para
         and c.object_type = 'TABLE'
         and a.tablespace_name = 'BI_DATA'
       order by b.column_id asc;
    
      insert_sql := 'insert into ' || user_shema || tw_table ||
                    cur_s.Table_Name || ' (' || insert_coluom_name ||
                    ',COVERNO)' || ' select ' || insert_coluom_name ||
                    ',nvl(''' || cur_s.load_coverno_value ||
                    ''','''') from ' || user_shema || cur_s.load_table_name;
      dbms_output.put_line('insert_sql_FULL :' || insert_sql);
      ------------------FULLִ��--------------��insert_sql��        
      EXECUTE IMMEDIATE insert_sql;
      --��===============================================================================================================��
      --��=======================================��TYPEΪPKʱ=============================================================��
      --��===============================================================================================================��
    elsif cur_s.LOAD_COVERNO_TYPE = 'PK' then
      --ͨ��PK����ɾ���ظ�
      --|==========================================================================================|
      --|=========================================PK_DELETE========================================|
      --|==========================================================================================|
      select BIETLUSER.fun_splitstr1(cur_s.LOAD_COVERNO_VALUE, '+')
        into where_str
        from dual;
      delete_sql := 'delete from ' || user_shema || tw_table ||
                    cur_s.Table_Name || ' a where exists  (select 1 from ' ||
                    user_shema || tw_table || cur_s.Table_Name || ' b ' ||
                    where_str || ')';
      dbms_output.put_line('delete_sql_PK :' || delete_sql);
      ------------------PKִ��--------------��delete_sql��      
      EXECUTE IMMEDIATE delete_sql;
      --|==========================================================================================|
      --|=========================================PK_INSERT========================================|
      --|==========================================================================================|
      table_name_para := ti_table || cur_s.Table_Name;
    
      select listagg(b.column_name, ',') within group(order by null)
        into insert_coluom_name
        from all_tables a, all_tab_columns b, all_objects c
       where a.table_name = b.table_name
         and a.owner = b.owner
         and a.owner = c.owner
         and a.table_name = c.object_name
         and a.table_name = table_name_para
         and c.object_type = 'TABLE'
         and a.tablespace_name = 'BI_DATA'
       order by b.column_id asc;
    
      insert_sql := 'insert into ' || user_shema || tw_table ||
                    cur_s.Table_Name || ' (' || insert_coluom_name ||
                    ',COVERNO)' || ' select ' || insert_coluom_name ||
                    ',nvl(''' || cur_s.load_coverno_value ||
                    ''','''') from ' || user_shema || cur_s.load_table_name;
    
      dbms_output.put_line('insert_sql_PK:' || insert_sql);
      ------------------PKִ��--------------��insert_sql��
      EXECUTE IMMEDIATE insert_sql;
      --��================================================================================================================��
      --��=======================================��TYPEΪEXPRʱ============================================================��
      --��================================================================================================================��      
    elsif cur_s.LOAD_COVERNO_TYPE = 'EXPR' then
      --ͨ��COVERNO����ɾ���ظ�
      --|==========================================================================================|
      --|=========================================EXPR_DELETE======================================|
      --|==========================================================================================|      
      delete_sql := 'delete from ' || user_shema || tw_table ||
                    cur_s.Table_Name || ' where COVERNO =''' ||
                    cur_s.load_coverno_value || '''';
      dbms_output.put_line('delete_sql_EXPR :' || delete_sql);
      ------------------EXPRִ��--------------��delete_sql�� 
      EXECUTE IMMEDIATE delete_sql;
      --|==========================================================================================|
      --|=========================================PK_INSERT========================================|
      --|==========================================================================================|
      table_name_para := ti_table || cur_s.Table_Name;
      select sys.wm_concat(b.column_name)
        into insert_coluom_name
        from all_tables a, all_tab_columns b, all_objects c
       where a.table_name = b.table_name
         and a.owner = b.owner
         and a.owner = c.owner
         and a.table_name = c.object_name
         and a.table_name = table_name_para
         and c.object_type = 'TABLE'
         and a.tablespace_name = 'BI_DATA'
       order by b.column_id asc;
    
      insert_sql := 'insert into ' || user_shema || tw_table ||
                    cur_s.Table_Name || ' (' || insert_coluom_name ||
                    ',COVERNO)' || ' select ' || insert_coluom_name ||
                    ',nvl(''' || cur_s.load_coverno_value ||
                    ''','''') from ' || user_shema || cur_s.load_table_name;
      dbms_output.put_line('ERROR: ' || insert_sql);
      ------------------EXPRִ��--------------��insert_sql��
      EXECUTE IMMEDIATE insert_sql;
    else
      dbms_output.put_line('error');
    end if;
  
  end loop;

end P_DEL_TW_REPEAT_DATA;
/
