CREATE procedure P_SUPPLY_SALE is
begin
       ---------------------------------------------------------供应商切片程序
  -------清空表
  delete from tb_report_supply;
  delete from tb_supply_sale;
  delete from tb_supply_sale_amount;
  
  -------生成供应商数据
  insert into tb_report_supply
    select factory_name,
           receiving_date,
           v1,
           v2,
           v3,
           material_name,
           material_number,
           receipt_quantity,
           tax_included_unit_price,
           receiving_unit,
           receipt_amount_tax_included,
           purchasing_group_description,
           order_type_name,
           supplier_name
      from tb_report_supply_temp;

  -------生成关联数据
  insert into tb_supply_sale
    with a as
     (select qingqiujh_date,
             customer_short_name,
             substr(item_number, 0, 7) item_number,
             description,
             sum(tax_amount_order) tax_amount_order
        from tb_report_bi
       group by qingqiujh_date,
                customer_short_name,
                item_number,
                description),
    b as
     (select receiving_date,
             material_number,
             material_name,
             sum(receipt_amount_tax_included) receipt_amount_tax_included,
             supplier_name
        from tb_report_supply
       group by receiving_date,
                material_number,
                material_name,
                supplier_name)
    select *
      from a
     inner join b
        on a.item_number = b.material_number
       and a.qingqiujh_date = b.receiving_date;

  -------生成采购，销售，金额
  insert into tb_supply_sale_amount
    with a as
     (select qingqiujh_date,
             sum(tax_amount_order) tax_amount_order
        from tb_report_bi
       group by qingqiujh_date),
    b as
     (select receiving_date,
             sum(receipt_amount_tax_included) receipt_amount_tax_included
        from tb_report_supply
       group by receiving_date)
    select *
      from a
     left join b
        on a.qingqiujh_date = b.receiving_date;


end P_SUPPLY_SALE;
/
